echo Hej hej
echo Nils är en svamp
echo Simona är en potatis
echo Victoria är ...958fei#¤%¤#¤%