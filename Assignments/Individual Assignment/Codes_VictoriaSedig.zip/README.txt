Hello!
To compile this program run makefile. That will give you 4 outputfiles to run. The ones that are noted optimized in the end are the ones with optimization flags.

To run the programs you type: 
./file SquereMatrixSize(int) #offThreads(int)

The codes has been test-run on vitsippa